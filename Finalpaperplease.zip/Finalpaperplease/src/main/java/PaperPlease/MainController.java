package PaperPlease;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import java.util.LinkedList;
import java.util.Queue;
import java.util.HashMap;
import java.util.Map;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;



public class MainController {
    @FXML
    public Label countryLabel;
    @FXML
    public Label nameLabel;
    @FXML
    public Label birthdayLabel;
    @FXML
    public Label sexLabel;
    @FXML
    public Label issuingCityLabel;
    @FXML
    public Label expirationLabel;
    @FXML
    public Label passportNumberLabel;

    public Queue<Person> peopleQueue;

    public Map<String, Person> peopleDictionary;

    @FXML
    private ImageView imageView;

    @FXML
    private ImageView passportImageView;

    @FXML
    private Label dayLabel;

    @FXML
    private TextArea ruleTextArea;

    @FXML
    private Label dateLabel;

    public int score = 0;
    @FXML
    private Label scoreLabel;
    public void loadFirstPersonData() {
        if (!peopleQueue.isEmpty()) {
            displayPersonDetails(peopleQueue.peek());
        }
    }
    public void initialize() {
        scoreLabel.setText("Score: " + score);
    }
    public MainController() {

        peopleDictionary = new HashMap<>();
        peopleQueue = new LinkedList<>();


        String[] names = {
                "John Doe", "Emily Smith", "Michael Johnson", "Sarah Anderson", "David Williams",
                "Sophia Garcia", "Ethan Martinez", "Olivia Brown", "Liam Wilson", "Ava Taylor"
        };

        String[] birthdays = {
                "1990.05.15", "1985.11.28", "1978.02.10", "1992.09.03", "1989.07.20",
                "1983.04.12", "1995.12.07", "1975.01.29", "1998.06.18", "1980.08.25"
        };

        String[] sexes = {
                "Male", "Female", "Male", "Female", "Male",
                "Female", "Male", "Female", "Male", "Female"
        };

        String[] issuingCities = {
                "New York", "London", "Manila", "Paris", "Rome",
                "Madrid", "Tokyo", "Sydney", "Moscow", "Beijing"
        };

        String[] expirations = {
                "2025.08.23", "2023.11.08", "2023.12.31", "2026.04.17", "2025.10.05",
                "2024.11.29", "2027.02.14", "2023.09.08", "2026.07.22", "2024.03.05"
        };

        String[] passportNumbers = {
                "ABC123", "XYZ789", "DEF456", "PQR567", "LMN890",
                "UVW234", "JKL901", "GHI345", "EFG678", "OPQ012"
        };

        String[] countries = {
                "USA", "UK", "Germany", "France", "Italy",
                "Spain", "Japan", "Australia", "Russia", "China"
        };

        String[] entryPermitNames = {
                "John Doe", "Emily Smith", "Michael Johnson", "Sarah Anderson", "Chovy Faker",
                "Sophia Garcia", "Ethan Martinez", "Olivia Brown", "Liam Wilson", "Ava Taylor"
        };

        String[] entryPermitNumbers = {
                "ABC123", "XYZ789", "DEF456", "PQR567", "LMN890",
                "KJA122", "JKL901", "GHI345", "EFG678", "OPQ012"
        };

        String[] entryDeadlines = {
                "2025.08.23", "2023.12.01", "2023.12.31", "2026.04.17", "2025.10.05",
                "2024.11.29", "2027.02.14", "2024.09.08", "2026.07.22", "2024.03.05"
        };

        String[] passportImagenumbers = {
                "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"
        };

        String[] takepicturenumbers = {
                "1", "2", "3", "4", "5", "6", "7", "11", "12", "10"
        };
        int[] dayNumbers = {1, 1, 1, 2, 2, 2, 3, 3, 4, 4};

        String[] passOrNot = {
                "Y", "N", "N", "Y", "N", "N", "Y", "N", "N", "Y"
        };

        for (int i = 0; i < names.length; i++) {
            Person person = new Person(countries[i], names[i], birthdays[i], sexes[i],
                    issuingCities[i], expirations[i], passportNumbers[i],
                    entryPermitNames[i], entryPermitNumbers[i], entryDeadlines[i], passportImagenumbers[i],
                    takepicturenumbers[i], dayNumbers[i], passOrNot[i]);

            peopleDictionary.put(names[i], person);
            peopleQueue.add(person);
        }

    }


    public void displayPersonDetails(Person person) {
        nameLabel.setText("Name: " + person.getName());
        birthdayLabel.setText("Birthday: " + person.getBirthday());
        sexLabel.setText("Sex: " + person.getSex());
        issuingCityLabel.setText("Issuing city: " + person.getIssuingCity());
        expirationLabel.setText("Expiration: " + person.getExpiration());
        passportNumberLabel.setText("Passport number: " + person.getPassportNumber());
        countryLabel.setText("Country: " + person.getCountry());
        loadPassportImage(person.getPassportimagenumber());
        dayLabel.setText("Day: " + person.getDayNumber());
        loadImage();
    }


    public void approveClicked() {
        if (!peopleQueue.isEmpty()) {
            Person currentPerson = peopleQueue.peek();
            if (currentPerson.getPassOrNot().equals("Y")) {
                score += 10;
            } else {
                score -= 5;
            }
            updateScoreLabel();
            peopleQueue.poll();

            if (!peopleQueue.isEmpty()) {
                displayPersonDetails(peopleQueue.peek());
                displayRulesBasedOnDayNumber(peopleQueue.peek().getDayNumber());
            } else {
                endGame();
            }
        }
    }


    public void rejectClicked() {
        if (!peopleQueue.isEmpty()) {
            Person currentPerson = peopleQueue.poll();
            if (currentPerson.getPassOrNot().equals("N")) {
                score += 10;
            } else {
                score -= 5;
            }
            updateScoreLabel();

            if (!peopleQueue.isEmpty()) {
                displayPersonDetails(peopleQueue.peek());
                displayRulesBasedOnDayNumber(peopleQueue.peek().getDayNumber());
            } else {
                endGame();
            }
        }
    }


    private void returnToMainMenu(Stage stage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("menu.fxml"));
            Parent root = loader.load();
            stage.setTitle("Menu");
            stage.setScene(new Scene(root, 600, 400));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void endGame() {
        Stage stage = (Stage) scoreLabel.getScene().getWindow();

        if (score >= 50) {

            showAlert("Congratulations!", "You won the game!");
            returnToMainMenu(stage);
        } else {

            showAlert("Game Over", "You lost the game. Try again!");
            returnToMainMenu(stage);
        }
    }
    public void updateScoreLabel() {
        scoreLabel.setText("Score: " + score);
    }


    private void loadImage() {

        String imagePath = getClass().getResource("13.png").toExternalForm();
        Image image = new Image(imagePath);

        imageView.setImage(image);
    }

    public void openPermitComparison() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("permit.fxml"));
            Parent root = loader.load();
            PermitController permitController = loader.getController();


            Person currentPerson = peopleQueue.peek();

            permitController.initData(currentPerson);

            Stage stage = new Stage();
            stage.setTitle("Permit Comparison");
            stage.setScene(new Scene(root, 293, 360));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void loadPassportImage(String passportImageNumber) {
        String imagePath = getClass().getResource(passportImageNumber + ".png").toExternalForm();
        Image image = new Image(imagePath);
        passportImageView.setImage(image);
    }

    public void openTakePicture() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("TakePicture.fxml"));
            Parent root = loader.load();
            TakePictureController takePictureController = loader.getController();


            Person currentPerson = peopleQueue.peek();


            takePictureController.initImageView(currentPerson.getTakepicturenumber());

            Stage stage = new Stage();
            stage.setTitle("Take Picture");
            stage.setScene(new Scene(root,249, 381));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void displayRulesBasedOnDayNumber(int dayNumber) {
        StringBuilder rules = new StringBuilder("Rules for today:\n");
        switch (dayNumber) {
            case 1:
                rules.append("1. The passport is authentic and valid (note: the issuing city of the passport must match the country, and pay attention to the validity period)\n");
                break;
            case 2:
                rules.append("1. The passport is authentic and valid (note: the issuing city of the passport must match the country, and pay attention to the validity period)\n");
                rules.append("2. Due to spy infiltration, everyone needs a pass to confirm identity (note: compare passport and ID card)\n");
                break;
            case 3:
                rules.append("1. The passport is authentic and valid (note: the issuing city of the passport must match the country, and pay attention to the validity period)\n");
                rules.append("2. Due to spy infiltration, everyone needs a pass to confirm identity (note: compare passport and ID card)\n");
                rules.append("3. Everyone needs to take a photo (note: compare with the picture in the passport)\n");
                break;
            case 4:
                rules.append("1. The passport is authentic and valid (note: the issuing city of the passport must match the country, and pay attention to the validity period)\n");
                rules.append("2. Due to spy infiltration, everyone needs a pass to confirm identity (note: compare passport and ID card)\n");
                rules.append("3. Everyone needs to take a photo (note: compare with the picture in the passport)\n");
                rules.append("4. Due to the increase in the number of refugees, people from country Russia are no longer allowed to enter the country\n");
                break;
            default:
                rules.append("No rules for today\n");
                break;
        }

        switch (dayNumber) {
            case 1:
                dateLabel.setText("Date today: 2023/12/4");
                break;
            case 2:
                dateLabel.setText("Date today: 2023/12/5");
                break;
            case 3:
                dateLabel.setText("Date today: 2023/12/6");
                break;
            case 4:
                dateLabel.setText("Date today: 2023/12/7");
                break;
            case 5:
                dateLabel.setText("Date today: 2023/12/8");
                break;
            default:
                dateLabel.setText("Date today: "); // Set a default value if needed
                break;}
        ruleTextArea.setText(rules.toString());
    }


}