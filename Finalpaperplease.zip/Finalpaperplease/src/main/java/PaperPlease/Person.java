package PaperPlease;

public class Person {
    public String country;
    public String name;
    public String birthday;
    public String sex;
    public String issuingCity;
    public String expiration;
    public String passportNumber;
    public String entryPermitName;
    public String entryPermitNumber;
    public String entryDeadline;


    public String getName() {
        return name;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getSex() {
        return sex;
    }

    public String getIssuingCity() {
        return issuingCity;
    }

    public String getExpiration() {
        return expiration;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public String passportimagenumber;

    public String getPassportimagenumber() {
        return passportimagenumber;
    }
    public String takepicturenumber;

    public String getTakepicturenumber() {
        return takepicturenumber;
    }
    public int dayNumber;
    public int getDayNumber() {
        return dayNumber;
    }

    public String passOrNot;

    public String getPassOrNot() {
        return passOrNot;
    }

    public Person(String country, String name, String birthday, String sex, String issuingCity,
                  String expiration, String passportNumber, String entryPermitName,
                  String entryPermitNumber, String entryDeadline, String passportimagenumber,
                  String takepicturenumber,int dayNumber,String passOrNot)  {
        this.country = country;
        this.name = name;
        this.birthday = birthday;
        this.sex = sex;
        this.issuingCity = issuingCity;
        this.expiration = expiration;
        this.passportNumber = passportNumber;
        this.entryPermitName = entryPermitName;
        this.entryPermitNumber = entryPermitNumber;
        this.entryDeadline = entryDeadline;
        this.passportimagenumber = passportimagenumber;
        this.takepicturenumber = takepicturenumber;
        this.dayNumber = dayNumber;
        this.passOrNot = passOrNot;
    }


    public String getCountry() {
        return country;
    }
    public String getEntryPermitName() {
        return entryPermitName;
    }

    public String getEntryPermitNumber() {
        return entryPermitNumber;
    }

    public String getEntryDeadline() {
        return entryDeadline;
    }


}