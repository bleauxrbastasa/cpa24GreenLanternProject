package PaperPlease;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import java.io.IOException;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;




public class Main extends Application {

    public ImageView logoImageView;
    private Stage primaryStage;


    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
        primaryStage.setTitle("Menu");
        primaryStage.setScene(new Scene(root, 600, 360));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void startGameClicked(ActionEvent event) {
        try {
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
            Parent root = loader.load();
            MainController controller = loader.getController();

            controller.loadFirstPersonData();
            controller.displayRulesBasedOnDayNumber(1);

            stage.setTitle("Game");
            stage.setScene(new Scene(root, 819, 585));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void initialize() {
        // Load the image into the logoImageView
        String imagePath = getClass().getResource("LOGO.jpg").toExternalForm();
        Image image = new Image(imagePath);
        logoImageView.setImage(image);
    }



}


