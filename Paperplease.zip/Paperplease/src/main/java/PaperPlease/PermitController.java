package PaperPlease;


import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class PermitController {
    @FXML
    private ImageView imageView;

    @FXML
    private Label nameLabel;

    @FXML
    private Label passportLabel;

    @FXML
    private Label dateLabel;

    public void initData(Person person) {
        nameLabel.setText(person.getEntryPermitName());
        passportLabel.setText(person.getEntryPermitNumber());
        dateLabel.setText(person.getEntryDeadline());

        String imagePath = getClass().getResource("14.png").toExternalForm();
        Image image = new Image(imagePath);
        imageView.setImage(image);
    }
}

