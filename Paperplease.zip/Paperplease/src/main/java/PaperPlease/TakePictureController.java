package PaperPlease;



import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class TakePictureController {
    @FXML
    private ImageView takePictureImageView;

    public void initImageView(String takepicturenumber) {
        String imagePath = getClass().getResource(takepicturenumber + ".png").toExternalForm();
        Image image = new Image(imagePath);
        takePictureImageView.setImage(image);
    }
}


